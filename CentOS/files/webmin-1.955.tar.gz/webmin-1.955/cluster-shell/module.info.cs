desc_cs=Cluster - Shell příkazy
