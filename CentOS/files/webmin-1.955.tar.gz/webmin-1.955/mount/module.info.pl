desc_pl=Lokalne i sieciowe systemy plików
